package com.example.pagepal;
import android.content.Intent;


import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;

public class LoginActivity extends AppCompatActivity {
    private EditText usernameField, passwordField;
    private Button registerBtn, loginBtn;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameField = findViewById(R.id.idEdtUsername);
        passwordField = findViewById(R.id.idEdtPassword);
        loginBtn = findViewById(R.id.idBtnLogin);
        registerBtn = findViewById(R.id.idBtnRegister);

        dbHandler = new DBHandler(LoginActivity.this);

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameField.getText().toString();
                String password = passwordField.getText().toString();

                // validating if the text fields are empty or not.
                if (username.isEmpty() && password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean login_result = dbHandler.login_user(username, password);

                if (login_result) {
                    int userId = dbHandler.get_user_id(username, password);
                    Toast.makeText(LoginActivity.this, "Login passed!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    startActivity(intent);

                    // Optionally, you can finish the LoginActivity to prevent going back to it
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Could not find user!", Toast.LENGTH_SHORT).show();
                }

                usernameField.setText("");
                passwordField.setText("");
            }
        });

        // Handle login logic here
        // If login successful, navigate to MainPageActivity
        // Finish LoginActivity to prevent going back to it after successful login
    }
}

