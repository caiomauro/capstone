package com.example.pagepal;

import static com.example.pagepal.DBHandler.USER_ID;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity {

    private DBHandler dbHandler;
    private int userId;
    private ArrayAdapter<String> adapter;
    private List<String[]> readings;
    private boolean isAdmin;

    // Constants
    private static final int PERMISSION_REQUEST_SMS = 1;

    // Member variables
    private boolean smsEnabled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        dbHandler = new DBHandler(this);
        TextView textView = findViewById(R.id.textView);
        EditText pagesReadEditText = findViewById(R.id.pagesReadEditText);
        Button addButton = findViewById(R.id.addButton);
        GridView gridView = findViewById(R.id.gridView);
        userId = UserSession.getInstance().getUserId();

        if (userId != -1) {
            String role = dbHandler.getUserRole(userId);
            isAdmin = "admin".equals(role);
            textView.setText("Hello, User " + userId + (isAdmin ? " (Admin)" : ""));
        } else {
            Toast.makeText(this, "User ID not available", Toast.LENGTH_SHORT).show();
        }

        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request the permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    PERMISSION_REQUEST_SMS);
        }

        // Set OnClickListener for the Add button
        addButton.setOnClickListener(view -> {
            String pagesReadString = pagesReadEditText.getText().toString();
            if (!pagesReadString.isEmpty()) {
                int pagesRead = Integer.parseInt(pagesReadString);
                long currentTime = System.currentTimeMillis();
                dbHandler.add_daily_reading(userId, pagesRead, currentTime);
                displayGrid();
                pagesReadEditText.setText("");
            } else {
                Toast.makeText(this, "Please enter pages read", Toast.LENGTH_SHORT).show();
            }
        });

        displayGrid();
        gridView.setOnItemClickListener((parent, view, position, id) -> showDeleteConfirmationDialog(position));
    }

    // Handle button click event
    public void onNotificationButtonClick(View view) {
        if (!smsEnabled) {
            // Enable SMS notifications
            smsEnabled = true;
            Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
        } else {
            // Send test SMS
            sendTestSMS();
        }
    }

    private void sendTestSMS() {
        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "1234567890"; // Replace with your phone number
            String message = "This is a test message.";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Test SMS sent", Toast.LENGTH_SHORT).show();
        } else {
            // Permission not granted, show a message or request permission again
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void displayGrid() {
        // Get the readings based on user role
        if (isAdmin) {
            readings = dbHandler.getAllDailyReadings();
        } else {
            readings = dbHandler.get_daily_readings(userId, 7);
        }

        GridView gridView = findViewById(R.id.gridView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        for (String[] reading : readings) {
            long unixTimestamp = Long.parseLong(reading[1]);
            int pagesRead = Integer.parseInt(reading[2]);
            String formattedDate = formatDate(unixTimestamp);
            String formattedReading = formattedDate + ": " + pagesRead + " pages read";
            adapter.add(formattedReading);
        }
        gridView.setAdapter(adapter);
    }

    private String formatDate(long unixTimestamp) {
        Date date = new Date(unixTimestamp);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return sdf.format(date);
    }

    private void showDeleteConfirmationDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Choose an action:")
                .setPositiveButton("Delete", (dialog, which) -> deleteEntry(position))
                .setNegativeButton("Update", (dialog, which) -> showUpdateDialog(position))
                .setNeutralButton("Cancel", null)
                .show();
    }

    private void deleteEntry(int position) {
        String[] reading = readings.get(position);
        long unixDate = Long.parseLong(reading[1]);
        dbHandler.delete_daily_reading(userId, unixDate);
        adapter.remove(adapter.getItem(position));
    }

    private void updateEntry(final int position, final int newPagesRead) {
        String[] reading = readings.get(position);
        long unixDate = Long.parseLong(reading[1]);
        dbHandler.update_daily_reading(userId, unixDate, newPagesRead);
        String formattedDate = formatDate(unixDate);
        String updatedReading = formattedDate + ": " + newPagesRead + " pages read";
        adapter.remove(adapter.getItem(position));
        adapter.insert(updatedReading, position);
    }

    private void showUpdateDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Pages Read");

        // Set up the layout for the dialog
        View view = getLayoutInflater().inflate(R.layout.dialog_update, null);
        builder.setView(view);

        // Find the EditText in the layout
        EditText pagesReadEditText = view.findViewById(R.id.pagesReadEditText);

        // Set up the buttons
        builder.setPositiveButton("Update", (dialog, which) -> {
            String pagesReadString = pagesReadEditText.getText().toString();
            if (!pagesReadString.isEmpty()) {
                int newPagesRead = Integer.parseInt(pagesReadString);
                updateEntry(position, newPagesRead);
            } else {
                Toast.makeText(HomeActivity.this, "Please enter pages read", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", null);

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
