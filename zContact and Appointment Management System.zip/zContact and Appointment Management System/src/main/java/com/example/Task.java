package com.example;

public class Task {
    private final String taskId;
    private final String name;
    private final String description;

    // Constructor, uses validation methods before adding inputs
    public Task(String taskId, String name, String description) {
        validateTaskId(taskId);
        validateName(name);
        validateDescription(description);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Get methods
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Methods to validate user input
    private void validateTaskId(String taskId) {
        if (taskId == null || taskId.isEmpty() || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must not be null and cannot exceed 10 characters.");
        }
    }

    void validateName(String name) {
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name must not be null and cannot exceed 20 characters.");
        }
    }

    private void validateDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null and cannot exceed 50 characters.");
        }
    }

    // Method to help print task
    @Override
    public String toString() {
        return "Task{" +
                "taskId='" + taskId + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    public static void main(String[] args) {
        try {
            Task task = new Task("T123", "Sample Task", "This is a sample task description.");
            System.out.println(task);
        } catch (IllegalArgumentException e) {
            System.out.println("Error creating task: " + e.getMessage());
        }
    }
}
