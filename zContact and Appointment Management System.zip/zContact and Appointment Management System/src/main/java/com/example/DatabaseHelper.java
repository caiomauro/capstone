package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseHelper {
    private static final String URL = "jdbc:sqlite:contacts.db";

    public static Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public static void createTables() {
        String createContactsTable = "CREATE TABLE IF NOT EXISTS contacts (" +
                "id TEXT PRIMARY KEY," +
                "firstName TEXT NOT NULL," +
                "lastName TEXT NOT NULL," +
                "address TEXT NOT NULL," +
                "phoneNumber TEXT NOT NULL" +
                ");";

        String createAppointmentsTable = "CREATE TABLE IF NOT EXISTS appointments (" +
                "id TEXT PRIMARY KEY," +
                "contactId TEXT," +
                "date TEXT NOT NULL," +
                "description TEXT," +
                "FOREIGN KEY(contactId) REFERENCES contacts(id)" +
                ");";

        String createTasksTable = "CREATE TABLE IF NOT EXISTS tasks (" +
                "id TEXT PRIMARY KEY," +
                "appointmentId TEXT," +
                "name TEXT NOT NULL," +
                "description TEXT," +
                "FOREIGN KEY(appointmentId) REFERENCES appointments(id)" +
                ");";

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(createContactsTable);
            stmt.execute(createAppointmentsTable);
            stmt.execute(createTasksTable);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void initializeData() {
        // Check if contacts table is empty
        String checkContactsSQL = "SELECT COUNT(*) FROM contacts";
        String insertContactsSQL = "INSERT INTO contacts (id, firstName, lastName, address, phoneNumber) VALUES (?, ?, ?, ?, ?)";

        // Check if appointments table is empty
        String checkAppointmentsSQL = "SELECT COUNT(*) FROM appointments";
        String insertAppointmentsSQL = "INSERT INTO appointments (id, contactId, date, description) VALUES (?, ?, ?, ?)";

        // Check if tasks table is empty
        String checkTasksSQL = "SELECT COUNT(*) FROM tasks";
        String insertTasksSQL = "INSERT INTO tasks (id, appointmentId, name, description) VALUES (?, ?, ?, ?)";

        try (Connection conn = connect();
                PreparedStatement checkContactsStmt = conn.prepareStatement(checkContactsSQL);
                ResultSet rsContacts = checkContactsStmt.executeQuery()) {

            if (rsContacts.next() && rsContacts.getInt(1) == 0) {
                // Table is empty, insert initial contacts
                try (PreparedStatement insertContactsStmt = conn.prepareStatement(insertContactsSQL)) {
                    // Sample contacts
                    insertContactsStmt.setString(1, "1");
                    insertContactsStmt.setString(2, "John");
                    insertContactsStmt.setString(3, "Doe");
                    insertContactsStmt.setString(4, "123 Elm Street");
                    insertContactsStmt.setString(5, "9995551234");
                    insertContactsStmt.executeUpdate();

                    insertContactsStmt.setString(1, "2");
                    insertContactsStmt.setString(2, "Jane");
                    insertContactsStmt.setString(3, "Smith");
                    insertContactsStmt.setString(4, "456 Oak Avenue");
                    insertContactsStmt.setString(5, "9999555678");
                    insertContactsStmt.executeUpdate();

                    System.out.println("Initial contacts inserted.");
                } catch (SQLException e) {
                    System.out.println("Error inserting initial contacts: " + e.getMessage());
                }
            } else {
                System.out.println("Contacts table already contains data.");
            }

            // Insert initial appointments
            try (PreparedStatement checkAppointmentsStmt = conn.prepareStatement(checkAppointmentsSQL);
                    ResultSet rsAppointments = checkAppointmentsStmt.executeQuery()) {

                if (rsAppointments.next() && rsAppointments.getInt(1) == 0) {
                    try (PreparedStatement insertAppointmentsStmt = conn.prepareStatement(insertAppointmentsSQL)) {
                        // Sample appointments
                        insertAppointmentsStmt.setString(1, "A001");
                        insertAppointmentsStmt.setString(2, "1"); // Contact ID
                        insertAppointmentsStmt.setString(3, "2024-09-01");
                        insertAppointmentsStmt.setString(4, "Doctor's appointment");
                        insertAppointmentsStmt.executeUpdate();

                        insertAppointmentsStmt.setString(1, "A002");
                        insertAppointmentsStmt.setString(2, "2"); // Contact ID
                        insertAppointmentsStmt.setString(3, "2024-09-15");
                        insertAppointmentsStmt.setString(4, "Meeting with client");
                        insertAppointmentsStmt.executeUpdate();

                        System.out.println("Initial appointments inserted.");
                    } catch (SQLException e) {
                        System.out.println("Error inserting initial appointments: " + e.getMessage());
                    }
                } else {
                    System.out.println("Appointments table already contains data.");
                }
            }

            // Insert initial tasks
            try (PreparedStatement checkTasksStmt = conn.prepareStatement(checkTasksSQL);
                    ResultSet rsTasks = checkTasksStmt.executeQuery()) {

                if (rsTasks.next() && rsTasks.getInt(1) == 0) {
                    try (PreparedStatement insertTasksStmt = conn.prepareStatement(insertTasksSQL)) {
                        // Sample tasks
                        insertTasksStmt.setString(1, "T001");
                        insertTasksStmt.setString(2, "A001"); // Appointment ID
                        insertTasksStmt.setString(3, "Prepare report");
                        insertTasksStmt.setString(4, "Prepare the financial report for the meeting.");
                        insertTasksStmt.executeUpdate();

                        insertTasksStmt.setString(1, "T002");
                        insertTasksStmt.setString(2, "A002"); // Appointment ID
                        insertTasksStmt.setString(3, "Review documents");
                        insertTasksStmt.setString(4, "Review the documents before the client meeting.");
                        insertTasksStmt.executeUpdate();

                        System.out.println("Initial tasks inserted.");
                    } catch (SQLException e) {
                        System.out.println("Error inserting initial tasks: " + e.getMessage());
                    }
                } else {
                    System.out.println("Tasks table already contains data.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error during initialization: " + e.getMessage());
        }
    }
}
