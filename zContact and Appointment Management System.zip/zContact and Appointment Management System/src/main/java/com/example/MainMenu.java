package com.example;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class MainMenu {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ContactService contactService = new ContactService();
    private static final TaskService taskService = new TaskService();

    public static void main(String[] args) {
        DatabaseHelper.createTables();
        DatabaseHelper.initializeData();

        boolean running = true;

        while (running) {
            System.out.println("Menu:");
            System.out.println("1. Create Contact");
            System.out.println("2. Create Appointment");
            System.out.println("3. Add Task to Appointment");
            System.out.println("4. View Appointments");
            System.out.println("5. Exit");

            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    createContact();
                    break;
                case 2:
                    createAppointment();
                    break;
                case 3:
                    addTaskToAppointment();
                    break;
                case 4:
                    viewAppointments();
                    break;
                case 5:
                    running = false;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createContact() {
        System.out.println("Enter Contact ID:");
        String id = scanner.nextLine();
        System.out.println("Enter First Name:");
        String firstName = scanner.nextLine();
        System.out.println("Enter Last Name:");
        String lastName = scanner.nextLine();
        System.out.println("Enter Address:");
        String address = scanner.nextLine();
        System.out.println("Enter Phone Number:");
        String number = scanner.nextLine();

        try {
            contactService.createContact(id, firstName, lastName, address, number);
            System.out.println("Contact created successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void createAppointment() {
        System.out.println("Enter Contact ID for Appointment:");
        String contactId = scanner.nextLine();

        System.out.println("Enter Appointment ID:");
        String appointmentId = scanner.nextLine();

        System.out.println("Enter Appointment Date (YYYY-MM-DD):");
        String dateString = scanner.nextLine();
        LocalDate date;
        try {
            date = LocalDate.parse(dateString); // Parse the input string to LocalDate
        } catch (DateTimeParseException e) {
            System.out.println("Error: Invalid date format. Please use YYYY-MM-DD.");
            return;
        }

        System.out.println("Enter Appointment Description:");
        String description = scanner.nextLine();

        try {
            Appointment appointment = new Appointment(appointmentId, date, description);
            contactService.addAppointment(contactId, appointment);
            System.out.println("Appointment created and added to contact.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void addTaskToAppointment() {
        System.out.println("Enter Appointment ID:");
        String appointmentId = scanner.nextLine();
        System.out.println("Enter Task ID:");
        String taskId = scanner.nextLine();
        System.out.println("Enter Task Name:");
        String name = scanner.nextLine();
        System.out.println("Enter Task Description:");
        String description = scanner.nextLine();

        try {
            Task task = new Task(taskId, name, description);
            taskService.addTask(task);

            boolean taskAdded = false;
            for (Contact contact : contactService.getcontacts().values()) {
                for (Appointment appointment : contact.getAppointments()) {
                    if (appointment.getAppointmentID().equals(appointmentId)) {
                        appointment.addTask(task);
                        System.out.println("Task added to appointment.");
                        taskAdded = true;
                        break;
                    }
                }
                if (taskAdded)
                    break;
            }

            if (!taskAdded) {
                System.out.println("Appointment not found.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewAppointments() {
        System.out.println("Enter Contact ID to view appointments:");
        String contactId = scanner.nextLine();

        Contact contact = contactService.getcontacts().get(contactId);
        if (contact != null) {
            System.out.println("Appointments for Contact ID " + contactId + ":");
            for (Appointment appointment : contact.getAppointments()) {
                System.out.println(appointment);
                for (Task task : appointment.getTasks()) {
                    System.out.println(" - " + task);
                }
            }
        } else {
            System.out.println("Contact not found.");
        }
    }
}
