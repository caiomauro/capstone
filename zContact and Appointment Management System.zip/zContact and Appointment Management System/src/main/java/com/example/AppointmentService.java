package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    // Method to load appointments from the database
    private Map<String, Appointment> loadAppointmentsFromDB() {
        Map<String, Appointment> appointments = new HashMap<>();
        String sql = "SELECT id, contactId, date, description FROM appointments";

        try (Connection conn = DatabaseHelper.connect();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String id = rs.getString("id");
                String contactId = rs.getString("contactId");
                LocalDate date = LocalDate.parse(rs.getString("date"));
                String description = rs.getString("description");

                Appointment appointment = new Appointment(id, date, description);
                appointments.put(id, appointment);
            }
        } catch (SQLException e) {
            System.out.println("Error loading appointments from database: " + e.getMessage());
        }
        return appointments;
    }

    // Get all appointments directly from the database
    public Map<String, Appointment> getAppointments() {
        return loadAppointmentsFromDB();
    }

    // Method to add an appointment
    public void addAppointment(Appointment appointment) {
        String sql = "INSERT INTO appointments(id, contactId, date, description) VALUES(?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            String appointmentID = appointment.getAppointmentID();
            // Check if appointment already exists in the database
            if (getAppointments().containsKey(appointmentID)) {
                throw new IllegalArgumentException("Appointment ID must be unique.");
            }

            pstmt.setString(1, appointmentID);
            pstmt.setString(2, ""); // Assuming contactId is not provided in Appointment object
            pstmt.setString(3, appointment.getDate().toString());
            pstmt.setString(4, appointment.getDescription());
            pstmt.executeUpdate();

            System.out.println("Appointment added");
        } catch (SQLException e) {
            System.out.println("Error adding appointment: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Method to remove an appointment
    public void removeAppointment(String appointmentID) {
        String sql = "DELETE FROM appointments WHERE id = ?";

        try (Connection conn = DatabaseHelper.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, appointmentID);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Appointment removed");
            } else {
                System.out.println("Appointment not found");
            }
        } catch (SQLException e) {
            System.out.println("Error removing appointment: " + e.getMessage());
        }
    }

    // Method to update appointment description
    public void updateAppointmentDescription(String appointmentID, String newDescription) {
        String sql = "UPDATE appointments SET description = ? WHERE id = ?";

        try (Connection conn = DatabaseHelper.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newDescription);
            pstmt.setString(2, appointmentID);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Appointment description updated");
            } else {
                System.out.println("Appointment not found");
            }
        } catch (SQLException e) {
            System.out.println("Error updating appointment description: " + e.getMessage());
        }
    }

    // Method to update appointment date
    public void updateAppointmentDate(String appointmentID, LocalDate newDate) {
        String sql = "UPDATE appointments SET date = ? WHERE id = ?";

        try (Connection conn = DatabaseHelper.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newDate.toString());
            pstmt.setString(2, appointmentID);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Appointment date updated");
            } else {
                System.out.println("Appointment not found");
            }
        } catch (SQLException e) {
            System.out.println("Error updating appointment date: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        // Initialize the database and load initial data
        DatabaseHelper.createTables();
        DatabaseHelper.initializeData();

        try {
            // Create a new AppointmentService instance which will load appointments from
            // the database
            AppointmentService appointmentService = new AppointmentService();

            // Define a new appointment
            LocalDate appointmentDate = LocalDate.of(2024, 12, 7);
            Appointment newAppointment = new Appointment("T123", appointmentDate,
                    "This is a sample appointment description.");

            // Add the new appointment to the database
            appointmentService.addAppointment(newAppointment);

            // Retrieve and print all appointments from the database
            Map<String, Appointment> appointments = appointmentService.getAppointments();
            System.out.println("All Appointments:");
            for (Appointment appointment : appointments.values()) {
                System.out.println(appointment);
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error creating appointment: " + e.getMessage());
        }
    }
}
