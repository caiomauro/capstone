package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = loadContactsFromDB();
    }

    // Load contacts from the database
    private Map<String, Contact> loadContactsFromDB() {
        Map<String, Contact> contacts = new HashMap<>();
        String sql = "SELECT id, firstName, lastName, address, phoneNumber FROM contacts";

        try (Connection conn = DatabaseHelper.connect();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String id = rs.getString("id");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String address = rs.getString("address");
                String phoneNumber = rs.getString("phoneNumber");

                Contact contact = new Contact(id, firstName, lastName, address, phoneNumber);
                contacts.put(id, contact);

                // Load associated appointments
                loadAppointmentsForContact(contact);
            }
        } catch (SQLException e) {
            System.out.println("Error loading contacts from database: " + e.getMessage());
        }
        return contacts;
    }

    private void loadAppointmentsForContact(Contact contact) {
        String sql = "SELECT id, date, description FROM appointments WHERE contactId = ?";
        try (Connection conn = DatabaseHelper.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, contact.getId());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String id = rs.getString("id");
                LocalDate date = LocalDate.parse(rs.getString("date"));
                String description = rs.getString("description");

                Appointment appointment = new Appointment(id, date, description);
                contact.addAppointment(appointment); // Add the appointment to the contact
            }
        } catch (SQLException e) {
            System.out.println("Error loading appointments for contact: " + e.getMessage());
        }
    }

    public Map<String, Contact> getcontacts() {
        return contacts;
    }

    // Create contact, auto add to map and database
    public void createContact(String ID, String firstName, String lastName, String address, String number) {
        Contact newContact = new Contact(ID, firstName, lastName, address, number);

        if (contacts.containsKey(newContact.ID)) {
            throw new IllegalArgumentException("Attempted to add contact but ID already exists");
        } else {
            String sql = "INSERT INTO contacts(id, firstName, lastName, address, phoneNumber) VALUES(?, ?, ?, ?, ?)";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, ID);
                pstmt.setString(2, firstName);
                pstmt.setString(3, lastName);
                pstmt.setString(4, address);
                pstmt.setString(5, number);
                pstmt.executeUpdate();

                contacts.put(ID, newContact);
            } catch (SQLException e) {
                System.out.println("Error adding contact: " + e.getMessage());
            }
        }
    }

    // Delete contact, removes from map and database
    public void deleteContact(String ID) {
        if (contacts.containsKey(ID)) {
            String sql = "DELETE FROM contacts WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, ID);
                pstmt.executeUpdate();
                contacts.remove(ID);

            } catch (SQLException e) {
                System.out.println("Error deleting contact: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException("Attempted to delete contact but ID does not exist in map");
        }
    }

    // Update methods
    public void updateFirstName(String ID, String firstName) {
        if (contacts.containsKey(ID)) {
            String sql = "UPDATE contacts SET firstName = ? WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, firstName);
                pstmt.setString(2, ID);
                pstmt.executeUpdate();

                Contact contact = contacts.get(ID);
                contact.setFirstName(firstName);

            } catch (SQLException e) {
                System.out.println("Error updating first name: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException(
                    "Attempted to update First Name for ID: " + ID + " but contact does not exist");
        }
    }

    public void updateLastName(String ID, String lastName) {
        if (contacts.containsKey(ID)) {
            String sql = "UPDATE contacts SET lastName = ? WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, lastName);
                pstmt.setString(2, ID);
                pstmt.executeUpdate();

                Contact contact = contacts.get(ID);
                contact.setLastName(lastName);

            } catch (SQLException e) {
                System.out.println("Error updating last name: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException(
                    "Attempted to update Last Name for ID: " + ID + " but contact does not exist");
        }
    }

    public void updateAddress(String ID, String address) {
        if (contacts.containsKey(ID)) {
            String sql = "UPDATE contacts SET address = ? WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, address);
                pstmt.setString(2, ID);
                pstmt.executeUpdate();

                Contact contact = contacts.get(ID);
                contact.setAddress(address);

            } catch (SQLException e) {
                System.out.println("Error updating address: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException(
                    "Attempted to update Address for ID: " + ID + " but contact does not exist");
        }
    }

    public void updateNumber(String ID, String number) {
        if (contacts.containsKey(ID)) {
            String sql = "UPDATE contacts SET phoneNumber = ? WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, number);
                pstmt.setString(2, ID);
                pstmt.executeUpdate();

                Contact contact = contacts.get(ID);
                contact.setNumber(number);

            } catch (SQLException e) {
                System.out.println("Error updating phone number: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException(
                    "Attempted to update Number for ID: " + ID + " but contact does not exist");
        }
    }

    // Add appointment to a contact
    public void addAppointment(String contactID, Appointment appointment) {
        if (contacts.containsKey(contactID)) {
            Contact contact = contacts.get(contactID);
            contact.addAppointment(appointment);

            // Add the appointment to the database
            String sql = "INSERT INTO appointments(id, contactId, date, description) VALUES(?, ?, ?, ?)";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, appointment.getAppointmentID());
                pstmt.setString(2, contactID);
                pstmt.setString(3, appointment.getDate().toString());
                pstmt.setString(4, appointment.getDescription());
                pstmt.executeUpdate();

            } catch (SQLException e) {
                System.out.println("Error adding appointment: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException(
                    "Attempted to add appointment for ID: " + contactID + " but contact does not exist");
        }
    }

    // Remove appointment from a contact
    public void removeAppointment(String contactID, String appointmentID) {
        if (contacts.containsKey(contactID)) {
            Contact contact = contacts.get(contactID);
            contact.removeAppointment(appointmentID);

            // Remove the appointment from the database
            String sql = "DELETE FROM appointments WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, appointmentID);
                pstmt.executeUpdate();

            } catch (SQLException e) {
                System.out.println("Error removing appointment: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException(
                    "Attempted to remove appointment for ID: " + contactID + " but contact does not exist");
        }
    }

    // Display methods
    public void displayKeys() {
        for (String i : contacts.keySet()) {
            System.out.println(i);
        }
    }

    public void displayObjects() {
        for (String i : contacts.keySet()) {
            System.out.println(contacts.get(i));
        }
    }

    public static void main(String[] args) {
        ContactService NewService = new ContactService();

        // Sample Data
        NewService.createContact("123ABC", "Caio", "Mauro", "115 Surfbird", "1234567890");
        NewService.createContact("456DEF", "Ariel", "Mauro", "115 Surfbird", "1234567899");

        // Adding appointments
        Appointment appointment1 = new Appointment("A123", LocalDate.now(), "Doctor's appointment");

        NewService.addAppointment("123ABC", appointment1);

        NewService.displayObjects();
    }

    // Update appointment description
    public void updateAppointmentDescription(String contactID, String appointmentID, String newDescription) {
        if (contacts.containsKey(contactID)) {
            Contact contact = contacts.get(contactID);
            for (Appointment appointment : contact.getAppointments()) {
                if (appointment.getAppointmentID().equals(appointmentID)) {
                    appointment.updateDescription(newDescription);

                    // Update the description in the database
                    String sql = "UPDATE appointments SET description = ? WHERE id = ?";

                    try (Connection conn = DatabaseHelper.connect();
                            PreparedStatement pstmt = conn.prepareStatement(sql)) {

                        pstmt.setString(1, newDescription);
                        pstmt.setString(2, appointmentID);
                        pstmt.executeUpdate();

                    } catch (SQLException e) {
                        System.out.println("Error updating appointment description: " + e.getMessage());
                    }

                    return;
                }
            }
            throw new IllegalArgumentException(
                    "Appointment ID: " + appointmentID + " does not exist for contact ID: " + contactID);
        } else {
            throw new IllegalArgumentException(
                    "Attempted to update appointment for ID: " + contactID + " but contact does not exist");
        }
    }

    // Update appointment date
    public void updateAppointmentDate(String contactID, String appointmentID, LocalDate newDate) {
        if (contacts.containsKey(contactID)) {
            Contact contact = contacts.get(contactID);
            for (Appointment appointment : contact.getAppointments()) {
                if (appointment.getAppointmentID().equals(appointmentID)) {
                    appointment.updateDate(newDate);

                    // Update the date in the database
                    String sql = "UPDATE appointments SET date = ? WHERE id = ?";

                    try (Connection conn = DatabaseHelper.connect();
                            PreparedStatement pstmt = conn.prepareStatement(sql)) {

                        pstmt.setString(1, newDate.toString());
                        pstmt.setString(2, appointmentID);
                        pstmt.executeUpdate();

                    } catch (SQLException e) {
                        System.out.println("Error updating appointment date: " + e.getMessage());
                    }

                    return;
                }
            }
            throw new IllegalArgumentException(
                    "Appointment ID: " + appointmentID + " does not exist for contact ID: " + contactID);
        } else {
            throw new IllegalArgumentException(
                    "Attempted to update appointment for ID: " + contactID + " but contact does not exist");
        }
    }
}
