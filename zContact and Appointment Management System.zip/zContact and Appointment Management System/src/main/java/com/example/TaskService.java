package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    // Creates task map
    public TaskService() {
        this.tasks = new HashMap<>();
        loadTasksFromDB();
    }

    // Load tasks from the database
    private void loadTasksFromDB() {
        String sql = "SELECT id, name, description FROM tasks";

        try (Connection conn = DatabaseHelper.connect();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String description = rs.getString("description");

                Task task = new Task(id, name, description);
                tasks.put(id, task);
            }
        } catch (SQLException e) {
            System.out.println("Error loading tasks from database: " + e.getMessage());
        }
    }

    // Adds task to map and database
    public void addTask(Task task) {
        if (task != null && !tasks.containsKey(task.getTaskId())) {
            String sql = "INSERT INTO tasks(id, name, description) VALUES(?, ?, ?)";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, task.getTaskId());
                pstmt.setString(2, task.getName());
                pstmt.setString(3, task.getDescription());
                pstmt.executeUpdate();

                tasks.put(task.getTaskId(), task);
                System.out.println("Task added successfully.");

            } catch (SQLException e) {
                System.out.println("Error adding task: " + e.getMessage());
            }
        } else {
            System.out.println("Task ID already exists or invalid task.");
        }
    }

    // Returns map
    public Map<String, Task> getTasks() {
        loadTasksFromDB();
        return tasks;
    }

    // Deletes task from map and database
    public void deleteTask(String id) {
        if (id != null && !id.isEmpty() && tasks.containsKey(id)) {
            String sql = "DELETE FROM tasks WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, id);
                pstmt.executeUpdate();

                tasks.remove(id);
                System.out.println("Task deleted successfully.");

            } catch (SQLException e) {
                System.out.println("Error deleting task: " + e.getMessage());
            }
        } else {
            System.out.println("This ID does not exist or invalid input.");
        }
    }

    // Updates task in map and database
    public void updateTask(String id, String name, String description) {
        if (id != null && !id.isEmpty() && tasks.containsKey(id)) {
            String sql = "UPDATE tasks SET name = ?, description = ? WHERE id = ?";

            try (Connection conn = DatabaseHelper.connect();
                    PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, name);
                pstmt.setString(2, description);
                pstmt.setString(3, id);
                pstmt.executeUpdate();

                Task task = new Task(id, name, description);
                tasks.put(id, task);
                System.out.println("Task updated successfully.");

            } catch (SQLException e) {
                System.out.println("Error updating task: " + e.getMessage());
            }
        } else {
            System.out.println("Task does not exist or error with input.");
        }
    }
}
