package com.example;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Appointment {
    private final String appointmentID;
    private LocalDate date;
    private String description;
    private List<Task> tasks; // List of tasks

    // Constructor
    public Appointment(String appointmentID, LocalDate date, String description) {
        validateAppointment(appointmentID);
        validateDate(date);
        validateDescription(description);

        this.appointmentID = appointmentID;
        this.date = date;
        this.description = description;
        this.tasks = new ArrayList<>(); // Initialize tasks list
    }

    // Get Methods
    public String getAppointmentID() {
        return appointmentID;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    private void validateAppointment(String appointmentID) {
        if (appointmentID == null || appointmentID.isEmpty() || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid appointmentID, appointment not created.");
        }
    }

    private void validateDate(LocalDate date) {
        LocalDate currentDate = LocalDate.now();
        if (date == null || date.isBefore(currentDate)) {
            throw new IllegalArgumentException("Invalid date, appointment not created.");
        }
    }

    private void validateDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description, appointment not created.");
        }
    }

    public void updateDescription(String newDescription) {
        validateDescription(newDescription);
        this.description = newDescription;
    }

    public void updateDate(LocalDate newDate) {
        validateDate(newDate); // Ensure date validation
        this.date = newDate;
    }

    // Add a task to the appointment
    public void addTask(Task task) {
        this.tasks.add(task);
    }

    // Method to help print appointment
    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentID='" + appointmentID + '\'' +
                ", date=" + date +
                ", description='" + description + '\'' +
                ", tasks=" + tasks +
                '}';
    }

    public static void main(String[] args) {
        try {
            LocalDate appointmentDate = LocalDate.of(2024, 12, 7);
            Appointment appointment = new Appointment("T123", appointmentDate,
                    "This is a sample appointment description.");
            System.out.println(appointment);
        } catch (IllegalArgumentException e) {
            System.out.println("Error creating appointment: " + e.getMessage());
        }
    }
}
