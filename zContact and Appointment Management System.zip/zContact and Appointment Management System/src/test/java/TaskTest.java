import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.example.Task;

public class TaskTest {

    //Creates test, should pass
    @Test
    void createTaskWithValidParameters() {
        String taskId = "T123";
        String name = "Sample Task";
        String description = "This is a sample task description.";

        Task task = new Task(taskId, name, description);

        assertEquals(taskId, task.getTaskId());
        assertEquals(name, task.getName());
        assertEquals(description, task.getDescription());
    }

    //Creates invalid task, should fail
    @Test
    void createTaskWithInvalidTaskId() {
        String invalidTaskId = "ThisIsTooLong";

        assertThrows(IllegalArgumentException.class, () -> new Task(invalidTaskId, "Valid Name", "Valid Description"));
    }

    //Creates invalid task, should fail
    @Test
    void createTaskWithInvalidName() {
        String invalidName = "ThisNameIsWayTooLongAndShouldCauseAnException";

        assertThrows(IllegalArgumentException.class, () -> new Task("ValidTaskId", invalidName, "Valid Description"));
    }

    //Creates invalid task, should fail
    @Test
    void createTaskWithInvalidDescription() {
        String invalidDescription = "ThisDescriptionIsTooLongAndShouldCauseAnExceptionBecauseItExceedsFiftyCharacters";

        assertThrows(IllegalArgumentException.class, () -> new Task("ValidTaskId", "Valid Name", invalidDescription));
    }
}
