import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.example.Appointment;

class AppointmentTest {

    // Valid appointment creation
    @Test
    void constructor_ValidParameters_ShouldCreateAppointmentSuccessfully() {
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment validAppointment = new Appointment("A123", appointmentDate, "Sample Appointment");

        assertEquals("A123", validAppointment.getAppointmentID());
        assertEquals(appointmentDate, validAppointment.getDate());
        assertEquals("Sample Appointment", validAppointment.getDescription());
    }

    // Invalid appointmentID, should throw IllegalArgumentException
    @Test
    void constructor_InvalidAppointmentID_ShouldThrowIllegalArgumentException() {
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, appointmentDate, "Sample Appointment");
        });
    }

    // Invalid date (before current date), should throw IllegalArgumentException
    @Test
    void constructor_InvalidDate_ShouldThrowIllegalArgumentException() {
        LocalDate invalidDate = LocalDate.of(2020, 1, 1); // Date in the past

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", invalidDate, "Sample Appointment");
        });
    }

    // Invalid description, should throw IllegalArgumentException
    @Test
    void constructor_InvalidDescription_ShouldThrowIllegalArgumentException() {
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", appointmentDate, null);
        });
    }

    // Update description, should work
    @Test
    void updateDescription_ValidDescription_ShouldUpdateDescriptionSuccessfully() {
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment appointment = new Appointment("A123", appointmentDate, "Sample Appointment");

        appointment.updateDescription("Updated Description");

        assertEquals("Updated Description", appointment.getDescription());
    }

    // Update description with invalid description, should throw
    // IllegalArgumentException
    @Test
    void updateDescription_InvalidDescription_ShouldThrowIllegalArgumentException() {
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment appointment = new Appointment("A123", appointmentDate, "Sample Appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.updateDescription(null);
        });
    }

    // Update date, should work
    @Test
    void updateDate_ValidDate_ShouldUpdateDateSuccessfully() {
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment appointment = new Appointment("A123", appointmentDate, "Sample Appointment");

        LocalDate newDate = LocalDate.of(2024, 5, 8); // New example date
        appointment.updateDate(newDate);

        assertEquals(newDate, appointment.getDate());
    }

    // Update date with invalid date, should throw IllegalArgumentException
    @Test
    void updateDate_InvalidDate_ShouldThrowIllegalArgumentException() {
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment appointment = new Appointment("A123", appointmentDate, "Sample Appointment");

        LocalDate invalidDate = LocalDate.of(2020, 1, 1); // Date in the past

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.updateDate(invalidDate);
        });
    }
}
