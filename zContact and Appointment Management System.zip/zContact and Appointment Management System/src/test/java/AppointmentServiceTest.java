import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.example.Appointment;
import com.example.AppointmentService;

class AppointmentServiceTest {

    // Adds an appointment that should work
    @Test
    void addAppointment_ValidAppointment_ShouldAddAppointmentSuccessfully() {
        AppointmentService appointmentService = new AppointmentService();
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment validAppointment = new Appointment("A123", appointmentDate, "Sample Appointment");

        appointmentService.addAppointment(validAppointment);

        assertTrue(appointmentService.getAppointments().containsKey("A123"));
    }

    // Removes an existing appointment
    @Test
    void removeAppointment_ExistingAppointment_ShouldRemoveAppointmentSuccessfully() {
        AppointmentService appointmentService = new AppointmentService();
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment validAppointment = new Appointment("A123", appointmentDate, "Sample Appointment");
        appointmentService.addAppointment(validAppointment);

        appointmentService.removeAppointment("A123");

        assertFalse(appointmentService.getAppointments().containsKey("A123"));
    }

    // Removes appointment that does not exist, should fail
    @Test
    void removeAppointment_NonExistingAppointment_ShouldPrintErrorMessage() {
        AppointmentService appointmentService = new AppointmentService();

        appointmentService.removeAppointment("NonExistingAppointment");
    }

    // Update appointment description, should work
    @Test
    void updateAppointmentDescription_ExistingAppointment_ShouldUpdateDescriptionSuccessfully() {
        AppointmentService appointmentService = new AppointmentService();
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment validAppointment = new Appointment("A123", appointmentDate, "Sample Appointment");
        appointmentService.addAppointment(validAppointment);

        appointmentService.updateAppointmentDescription("A123", "Updated Description");

        assertEquals("Updated Description", appointmentService.getAppointments().get("A123").getDescription());
    }

    // Update appointment description for non-existing appointment, should fail
    @Test
    void updateAppointmentDescription_NonExistingAppointment_ShouldPrintErrorMessage() {
        AppointmentService appointmentService = new AppointmentService();

        appointmentService.updateAppointmentDescription("NonExistingAppointment", "Updated Description");
    }

    // Update appointment date through the service, should work
    @Test
    void updateAppointmentDate_ExistingAppointment_ShouldUpdateDateSuccessfully() {
        AppointmentService appointmentService = new AppointmentService();
        LocalDate appointmentDate = LocalDate.of(2024, 5, 7); // Example date
        Appointment validAppointment = new Appointment("A123", appointmentDate, "Sample Appointment");
        appointmentService.addAppointment(validAppointment);

        LocalDate newDate = LocalDate.of(2024, 5, 8); // New example date
        appointmentService.updateAppointmentDate("A123", newDate);

        assertEquals(newDate, appointmentService.getAppointments().get("A123").getDate());
    }

    // Update appointment date for non-existing appointment, should fail
    @Test
    void updateAppointmentDate_NonExistingAppointment_ShouldPrintErrorMessage() {
        AppointmentService appointmentService = new AppointmentService();

        LocalDate newDate = LocalDate.of(2024, 5, 8); // New example date
        appointmentService.updateAppointmentDate("NonExistingAppointment", newDate);
    }
}
