import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.example.Task;
import com.example.TaskService;

class TaskServiceTest {

    //Adds a task that should work
    @Test
    void addTask_ValidTask_ShouldAddTaskSuccessfully() {
        TaskService taskService = new TaskService();
        Task validTask = new Task("T123", "Sample Task", "This is a sample task description.");

        taskService.addTask(validTask);

        assertTrue(taskService.getTasks().containsKey("T123"));
    }

    //Deletes an existing task
    @Test
    void deleteTask_ExistingTask_ShouldDeleteTaskSuccessfully() {
        TaskService taskService = new TaskService();
        Task validTask = new Task("T123", "Sample Task", "This is a sample task description.");
        taskService.addTask(validTask);

        taskService.deleteTask("T123");

        assertFalse(taskService.getTasks().containsKey("T123"));
    }

    //Deletes task that does not exist, should fail
    @Test
    void deleteTask_NonExistingTask_ShouldPrintErrorMessage() {
        TaskService taskService = new TaskService();

        taskService.deleteTask("NonExistingTask");
    }


    //Updates task, should work
    @Test
    void updateTask_ExistingTask_ShouldUpdateTaskSuccessfully() {
        TaskService taskService = new TaskService();
        Task initialTask = new Task("T123", "Sample Task", "This is a sample task description.");
        taskService.addTask(initialTask);

        taskService.updateTask("T123", "Updated Task", "This is the updated task description.");

        Task updatedTask = taskService.getTasks().get("T123");
        assertEquals("Updated Task", updatedTask.getName());
        assertEquals("This is the updated task description.", updatedTask.getDescription());
    }

    //Updates task, should fail  
    @Test
    void updateTask_NonExistingTask_ShouldPrintErrorMessage() {
        TaskService taskService = new TaskService();

        taskService.updateTask("NonExistingTask", "Updated Task", "This is the updated task description.");
    }
}
